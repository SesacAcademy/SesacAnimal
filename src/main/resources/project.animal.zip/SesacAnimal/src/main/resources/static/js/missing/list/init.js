
export const count = _count;
export const page = _page;
export const size = _size;
export const maxPageCount = Math.ceil(count / size);

export const search = _search;
export const animalType = _animalType;
export const specifics =_specifics;
export const color =_color;
export const fromDate =_fromDate;
export const endDate = _endDate;

console.log("search", search);
console.log("animalType", animalType);
console.log("specifics", specifics);
console.log("color", color);
console.log("fromDate", fromDate);
console.log("endDate", endDate);
