package com.project.animal.missing.dummy;

import com.project.animal.missing.domain.MissingPost;
import com.project.animal.missing.dto.MissingListEntryDto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class MissingPostDummy {
  private static List<MissingPost> dummyPost = List.of(
          new MissingPost(1, 1,"Lost Friendly Dog, faepoefjawpofawpofjawfeawfoawpj", "dog","persian", "Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog", "persian","Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog","persian", "Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog", "persian","Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog","persian", "Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog", "persian","Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog", "persian","Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog","persian", "Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog","persian", "Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1),
          new MissingPost(1, 1,"Lost Friendly Dog", "dog","persian", "Brown", 150, "Central Park", LocalDateTime.now(), "Sma dog with a red collar and a friendly demeanor.", 0, 'L', 1)


  );

  public static List<MissingPost> getList() {
    return dummyPost;
  }

  public static List<MissingListEntryDto> getDummyDto() {
   return dummyPost.stream().map((entity) -> MissingListEntryDto.fromMissingPost(entity)).collect(Collectors.toList());
  }
}
