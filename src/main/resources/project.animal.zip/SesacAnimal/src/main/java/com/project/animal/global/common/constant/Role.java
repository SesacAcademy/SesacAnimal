package com.project.animal.global.common.constant;

public enum Role {
    ROLE_USER, ROLE_ADMIN           // Spring Security에서 Role은 무조건 접두사 "ROLE_"이 붙어야 한다.
}
