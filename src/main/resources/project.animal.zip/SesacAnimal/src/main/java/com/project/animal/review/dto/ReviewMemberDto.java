package com.project.animal.review.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class ReviewMemberDto {
    private Long id;
    private String nickname;
}
