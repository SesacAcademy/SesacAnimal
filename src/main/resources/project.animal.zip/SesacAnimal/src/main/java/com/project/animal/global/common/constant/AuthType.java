package com.project.animal.global.common.constant;

public enum AuthType {
    MAIL, PHONE, JWT, GOOGLE, NAVER, KAKAO
}
